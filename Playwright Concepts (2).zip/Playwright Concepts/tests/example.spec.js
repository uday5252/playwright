import { test, expect } from '@playwright/test';
import { Login } from "../pages/Login.js"
import * as data from "xlsx"

const file = data.readFile("C:/Users/udayk/OneDrive/Desktop/Playwright Concepts/utils/githublogindata.xlsx")

    const sheetName = file.SheetNames[0]

    const sheet = file.Sheets[sheetName]

    const jsonData = data.utils.sheet_to_json(sheet)


for(let loginData of jsonData)
{   
    
test(`Login to github using ${loginData.username} and ${loginData.password}`, async ({ page }) =>
{
        await page.goto("https://github.com/login")

        const login = new Login(page)
        
        await login.enterUsername(loginData.username)
        await login.enterPassword(loginData.password)
        await login.clickLogin()

        // verify the confirmation / validation / assertions
        const outputText = await login.verifyHomePageTitle()
        expect(outputText).toContain("Home")

    })

}