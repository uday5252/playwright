
export class Login 
{
    constructor(page)
    {
        this.page = page
        this.username = "xpath=//input[@name='login']"
        this.password = "xpath=//input[@name='password']"
        this.loginBtn = "xpath=//input[@value='Sign in']"
        this.homePageText = "xpath=//h2[text()='Home']"
    }

    async enterUsername(email)
    {
        await this.page.locator(this.username).fill(email)
    }

    async enterPassword(password)
    {
        await this.page.locator(this.password).fill(password)
    }

    async clickLogin()
    {
        await this.page.locator(this.loginBtn).click()
    }

    async verifyHomePageTitle()
    {
        const recievedText = await this.page.locator(this.homePageText).textContent()        
        return recievedText
    }
}
