export function add(num1, num2)
{
    return num1 + num2
} 

export function sub(num1, num2)
{
    return num1 + num2
} 

export function mul(num1, num2)
{
    return num1 * num2
} 

export function div(num1, num2)
{
    return num1 / num2
} 
