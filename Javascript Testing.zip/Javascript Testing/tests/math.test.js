import  { expect } from "chai"
import { describe, it } from "mocha"
import { add, sub, mul, div } from "../math.js"

// Code to test 4 functions are correct OR not

describe("Checking calculator app", function()
{
    it("Check whether add is working or not", ()=>
    {
            // logic to check add()
            expect(add(10, 20)).to.be.equal(30)
        
    })

    it("Check whether sub is working or not", function()
    {
            // logic to check sub()
            expect(sub(10, 20)).to.be.equal(-10)
    })

    it("Check whether mul is working or not", function()
    {
            // logic to check mul()
            expect(mul(10, 20)).to.be.equal(200)
    })

    it("Check whether div is working or not", function(){
            
            // logic to check div()
            expect(div(10, 5)).to.be.equal(2)
    })
})
