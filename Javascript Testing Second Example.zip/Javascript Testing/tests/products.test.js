import { fetchProducts } from "../products.js"
import { expect } from "chai"


describe("Test fake products info!", function()
{
    this.timeout(10000)

    it("Check the length of the products!", async function()
    {
        const productsOutput = await fetchProducts()
        
        expect(productsOutput.length).to.be.equal(20)
    })

    it("Check whether the product has id, title, price, description keys or not", async function()
    {
        const productsOutput = await fetchProducts()
        const firstProduct = productsOutput[0]
        expect(firstProduct).to.have.property("id")
        expect(firstProduct).to.have.property("title")
        expect(firstProduct).to.have.property("price")
    })
})