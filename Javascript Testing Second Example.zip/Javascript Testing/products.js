
import myaxios from "axios";

export async function fetchProducts()
{
    const output = await myaxios.get("https://fakestoreapi.com/products") // 100 sec
    return output.data
}

